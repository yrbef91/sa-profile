@extends('vendor.crud.single-page-templates.common.app')

@section('content')

    <h2>Update Customer: {{$customer->title}}</h2>

    <form action="{{ url('/customer/' . $customer->id) }}" method="post">

        {{ csrf_field() }}

        {{ method_field("PUT") }}

        {!! \Nvd\Crud\Form::input('title','text')->model($customer)->show() !!}

        {!! \Nvd\Crud\Form::textarea( 'body' )->model($customer)->show() !!}

        <button type="submit" class="btn btn-default">Submit</button>

    </form>

@endsection