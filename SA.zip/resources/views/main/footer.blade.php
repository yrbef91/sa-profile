	<footer id="footer"> 
		<div class="container"> 
			<div class="text-center"> 
				<p>Copyright &copy; 2016 - <a href="{{ URL::to('/') }}">Smart Aircraft</a> | All Rights Reserved</p> 
			</div> 
		</div> 
	</footer> <!--/#footer-->