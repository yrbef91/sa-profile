<!DOCTYPE html>
<html lang="en">
<head> 
	<meta charset="utf-8"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<meta name="description" content="Smart Aircraft">
	<meta name="keywords" content="Aerospace Smart Solutions, Aircraft, Aerospace, Solutions" /> 
	<meta name="author" content="Smart Aircraft"> 
	<title>Smart Aircraft - Aerospace Smart Solutions</title> 
	<link href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('css/prettyPhoto.css')); ?>" rel="stylesheet"> 
	<link href="<?php echo e(URL::asset('css/font-awesome.min.css')); ?>" rel="stylesheet"> 
	<link href="<?php echo e(URL::asset('css/animate.css')); ?>" rel="stylesheet"> 
	<link href="<?php echo e(URL::asset('css/main.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('css/responsive.css')); ?>" rel="stylesheet"> 
	<!--[if lt IE 9]> <script src="js/html5shiv.js"></script> 
	<script src="js/respond.min.js"></script> <![endif]--> 
	<link rel="shortcut icon" href="<?php echo e(URL::asset('images/ico/favicon.png')); ?>"> 
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(URL::asset('images/ico/apple-touch-icon-144-precomposed.png')); ?>"> 
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(URL::asset('images/ico/apple-touch-icon-114-precomposed.png')); ?>"> 
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(URL::asset('images/ico/apple-touch-icon-72-precomposed.png')); ?>"> 
	<link rel="apple-touch-icon-precomposed" href="<?php echo e(URL::asset('images/ico/apple-touch-icon-57-precomposed.png')); ?>">
</head><!--/head-->
<body>

	<?php echo $__env->make('main.preloader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php echo $__env->make('main.header_navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php echo $__env->make('main.section_home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php echo $__env->make('main.section_about', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('main.section_services', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php echo $__env->make('main.section_our_team', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('main.section_portofolio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	

	<?php echo $__env->make('main.section_clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php echo $__env->make('main.section_blog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('main.section_contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('main.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script> 
	<script type="text/javascript" src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(URL::asset('js/smoothscroll.js')); ?>"></script> 
	<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.isotope.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.prettyPhoto.js')); ?>"></script> 
	<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.parallax.js')); ?>"></script> 
	<script type="text/javascript" src="<?php echo e(URL::asset('js/main.js')); ?>"></script> 
</body>
</html>