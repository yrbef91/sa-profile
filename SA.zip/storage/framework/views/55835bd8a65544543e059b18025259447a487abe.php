<?php $__env->startSection('content'); ?>

    <h2>Customer: <?php echo e($customer->title); ?></h2>

    <ul class="list-group">

        <li class="list-group-item">
            <h4>Id</h4>
            <h5><?php echo e($customer->id); ?></h5>
        </li>
        <li class="list-group-item">
            <h4>Title</h4>
            <h5><?php echo e($customer->title); ?></h5>
        </li>
        <li class="list-group-item">
            <h4>Body</h4>
            <h5><?php echo e($customer->body); ?></h5>
        </li>
        <li class="list-group-item">
            <h4>Created At</h4>
            <h5><?php echo e($customer->created_at); ?></h5>
        </li>
        <li class="list-group-item">
            <h4>Updated At</h4>
            <h5><?php echo e($customer->updated_at); ?></h5>
        </li>
        
    </ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.crud.single-page-templates.common.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>