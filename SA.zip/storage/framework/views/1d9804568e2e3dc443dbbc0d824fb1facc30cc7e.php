<?php $__env->startSection('content'); ?>

	<h2>Customers</h2>

	<?php echo $__env->make('customer.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="col-md-12" style="padding-left: 0">
		<table class="table table-striped grid-view-tbl">
			
			<thead>
			<tr class="header-row">
				<?php echo \Nvd\Crud\Html::sortableTh('id','customer.index','Id'); ?>

				<?php echo \Nvd\Crud\Html::sortableTh('title','customer.index','Title'); ?>

				<?php echo \Nvd\Crud\Html::sortableTh('body','customer.index','Body'); ?>

				<?php echo \Nvd\Crud\Html::sortableTh('created_at','customer.index','Created At'); ?>

				<?php echo \Nvd\Crud\Html::sortableTh('updated_at','customer.index','Updated At'); ?>

				<th></th>
			</tr>
			<tr class="search-row">
				<form class="search-form">
					<td><input type="text" class="form-control" name="id" value="<?php echo e(Request::input("id")); ?>"></td>
					<td><input type="text" class="form-control" name="title" value="<?php echo e(Request::input("title")); ?>"></td>
					<td><input type="text" class="form-control" name="body" value="<?php echo e(Request::input("body")); ?>"></td>
					<td><input type="text" class="form-control" name="created_at" value="<?php echo e(Request::input("created_at")); ?>"></td>
					<td><input type="text" class="form-control" name="updated_at" value="<?php echo e(Request::input("updated_at")); ?>"></td>
					<td style="min-width: 6em;"><?php echo $__env->make('vendor.crud.single-page-templates.common.search-btn', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
				</form>
			</tr>
			</thead>

			<tbody>
				<?php $__empty_1 = true; foreach( $records as $record ): $__empty_1 = false; ?>
					<tr>
						<td>
							<?php echo e($record->id); ?>

							</td>
						<td>
							<span class="editable"
								  data-type="text"
								  data-name="title"
								  data-value="<?php echo e($record->title); ?>"
								  data-pk="<?php echo e($record->{$record->getKeyName()}); ?>"
								  data-url="/customer/<?php echo e($record->{$record->getKeyName()}); ?>"
								  ><?php echo e($record->title); ?></span>
							</td>
						<td>
							<span class="editable"
								  data-type="textarea"
								  data-name="body"
								  data-value="<?php echo e($record->body); ?>"
								  data-pk="<?php echo e($record->{$record->getKeyName()}); ?>"
								  data-url="/customer/<?php echo e($record->{$record->getKeyName()}); ?>"
								  ><?php echo e($record->body); ?></span>
							</td>
						<td>
							<?php echo e($record->created_at); ?>

							</td>
						<td>
							<?php echo e($record->updated_at); ?>

							</td>
						<?php echo $__env->make( 'vendor.crud.single-page-templates.common.actions', [ 'url' => 'customer', 'record' => $record ] , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</tr>
				<?php endforeach; if ($__empty_1): ?>
					<?php echo $__env->make('vendor.crud.single-page-templates.common.not-found-tr',['colspan' => 6], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php endif; ?>
			</tbody>

		</table>
	</div>

	<?php echo $__env->make('vendor.crud.single-page-templates.common.pagination', [ 'records' => $records ] , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
	$(".editable").editable({ajaxOptions:{method:'PUT'}});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.crud.single-page-templates.common.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>