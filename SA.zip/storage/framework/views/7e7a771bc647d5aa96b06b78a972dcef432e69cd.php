<?php $__env->startSection('content'); ?>

    <h2>Update Customer: <?php echo e($customer->title); ?></h2>

    <form action="<?php echo e(url('/customer/' . $customer->id)); ?>" method="post">

        <?php echo e(csrf_field()); ?>


        <?php echo e(method_field("PUT")); ?>


        <?php echo \Nvd\Crud\Form::input('title','text')->model($customer)->show(); ?>


        <?php echo \Nvd\Crud\Form::textarea( 'body' )->model($customer)->show(); ?>


        <button type="submit" class="btn btn-default">Submit</button>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.crud.single-page-templates.common.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>